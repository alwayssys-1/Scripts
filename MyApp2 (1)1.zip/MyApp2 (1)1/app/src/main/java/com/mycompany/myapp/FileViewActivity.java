package com.mycompany.myapp;

import android.support.v7.app.*;
import android.os.*;
import java.io.*;
import android.widget.*;

public class FileViewActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_view);

        String path = getIntent().getStringExtra("path");
        File file = new File(path);

        TextView nameView = findViewById(R.id.nameView);
        TextView contentView = findViewById(R.id.contentView);

        nameView.setText(file.getName());

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            br.close();
            contentView.setText(sb.toString());
        } catch (Exception e) {
            contentView.setText("No se pudo leer: " + e.getMessage());
        }
    }
}
