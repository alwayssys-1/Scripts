package com.mycompany.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.*;
import java.util.regex.*;
import android.content.*;
import android.preference.*;
import java.util.*;
import android.content.res.*;
import android.net.*;
import java.io.*;
import android.widget.*;
import android.view.*;
import java.util.concurrent.*;
import android.text.*;
import android.support.v4.content.*;
import android.os.*;
import android.support.v4.app.*;
import android.content.pm.*;
import android.*;

public class MainActivity extends AppCompatActivity {
	private static String TAG = "xxxxxx";
    private static final int RQC = 1;
    private String[] grupoPermisos = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
	// Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS};
	private ListView listView;
    private TextView pathView;
    private File currentDir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		compruebaPermiso();
		
		listView = findViewById(R.id.listView);
        pathView = findViewById(R.id.pathView);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this, grupoPermisos, RQC);
		} else {
			getFile(Environment.getExternalStorageDirectory()); // se ve al abrir
		}
	}

	private void compruebaPermiso() {
		for (String cad: grupoPermisos){
			if (ContextCompat.checkSelfPermission(this,cad) == PackageManager.PERMISSION_DENIED){
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
					//requestPermissions(new String[]{cad}, RQC);
					ActivityCompat.requestPermissions( 
						MainActivity.this, 
						new String[] {cad}, 
						RQC);

				}
			}
		}
	}

	private void getFile(File dir) {
        currentDir = dir;
        pathView.setText(dir.getAbsolutePath());
        File[] files = dir.listFiles();
        List<String> nombres = new ArrayList<>();

        if (files!= null) {
            for (File f : files) {
                nombres.add(f.getName() + (f.isDirectory()? "/" : ""));
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, nombres);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				File[] files = currentDir.listFiles();
				if (files == null) return;

				File seleccionado = files[position]; // <- esto te faltaba
				if (seleccionado.isDirectory()) {
					getFile(seleccionado);
				} else {
					Toast.makeText(MainActivity.this, "Fichero: " + seleccionado.getName(), Toast.LENGTH_SHORT).show();
				}
					// dentro del onItemClick, en el else:
					/*
				} else {
					Intent intent = new Intent(MainActivity.this, FileViewActivity.class);
					intent.putExtra("path", seleccionado.getAbsolutePath());
					startActivity(intent);
				}*/
			}
		});
	}

    @Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == RQC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
			getFile(Environment.getExternalStorageDirectory()); // se ve después de aceptar permiso
		}
	}
}

